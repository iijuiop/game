using UnityEngine;

public class EnemyController : MonoBehaviour
{
    public float moveSpeed = 2f; // Tốc độ di chuyển của quái vật
    public float attackRange = 1f; // Khoảng cách để quái vật bắt đầu tấn công
    public float attackCooldown = 2f; // Thời gian chờ giữa các lần tấn công
    public float patrolDistance = 5f; // Khoảng cách quái vật đi lại trong chế độ tuần tra

    private Transform player; // Tham chiếu đến nhân vật người chơi
    private Rigidbody2D rb;
    private Animator animator;

    private float lastAttackTime; // Thời điểm tấn công cuối cùng
    private Vector2 startPosition; // Vị trí bắt đầu của quái vật để tuần tra
    private bool movingRight = true; // Hướng di chuyển trong chế độ tuần tra

    public int pointsToSteal = 5; // Số điểm quái vật sẽ lấy của người chơi khi tấn công

    // Biến để lưu trữ HP của quái vật (ví dụ) - Giữ lại nếu quái vật có HP và có thể bị người chơi đánh
    public int currentHealth = 100;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();

        GameObject playerObject = GameObject.FindGameObjectWithTag("Player");
        if (playerObject != null)
        {
            player = playerObject.transform;
        }
        else
        {
            Debug.LogWarning("Không tìm thấy đối tượng 'Player' với Tag 'Player'. Quái vật sẽ không thể theo dõi người chơi.");
        }

        startPosition = transform.position;
        lastAttackTime = -attackCooldown;
    }

    void Update()
    {
        if (player == null)
        {
            Patrol();
            return;
        }

        float distanceToPlayer = Vector2.Distance(transform.position, player.position);

        if (distanceToPlayer <= attackRange)
        {
            AttackPlayer();
        }
        else
        {
            ChasePlayer();
        }

        if (animator != null)
        {
            animator.SetFloat("Speed", Mathf.Abs(rb.linearVelocity.x)); // Sử dụng rb.velocity.x
        }
    }

    void ChasePlayer()
    {
        Vector2 direction = (player.position - transform.position).normalized;
        rb.linearVelocity = new Vector2(direction.x * moveSpeed, rb.linearVelocity.y); // Sử dụng rb.velocity.y
        Flip(direction.x);

        if (animator != null)
        {
            animator.SetBool("IsAttacking", false);
        }
    }

    void AttackPlayer()
    {
        if (player.position.x < transform.position.x)
        {
            Flip(-1);
        }
        else
        {
            Flip(1);
        }

        if (Time.time >= lastAttackTime + attackCooldown)
        {
            Debug.Log("Quái vật bắt đầu tấn công!");

            if (animator != null)
            {
                animator.SetBool("IsAttacking", true); // Kích hoạt animation tấn công
            }
            

            lastAttackTime = Time.time;
        }
        else
        {
            if (animator != null)
            {
                animator.SetBool("IsAttacking", false);
            }
        }
    }

    // HÀM MỚI SẼ ĐƯỢC GỌI BỞI ANIMATION EVENT
 public void PerformHit()
{
    if (player != null)
    {
        float currentDistanceToPlayer = Vector2.Distance(transform.position, player.position);
        if (currentDistanceToPlayer <= attackRange + 0.1f) // +0.1f là dung sai nhỏ
        {
            PlayerMovement2D playerScript = player.GetComponent<PlayerMovement2D>();
            if (playerScript != null)
            {
                playerScript.LoseScore(pointsToSteal);
                Debug.Log("Quái vật đã tấn công người chơi và lấy " + pointsToSteal + " điểm!");
            }
            else
            {
                Debug.LogError("Không tìm thấy script 'PlayerMovement2D' trên đối tượng 'Player'!");
            }
        }
        else
        {
            Debug.Log("Quái vật đánh hụt vì người chơi đã di chuyển ra xa.");
        }
    }

    // THÊM DÒNG NÀY: Reset tham số IsAttacking về false
    if (animator != null)
    {
        animator.SetBool("IsAttacking", false);
    }
}

    void Patrol()
    {
        if (movingRight)
        {
            rb.linearVelocity = new Vector2(moveSpeed, rb.linearVelocity.y);
            Flip(1);
            if (transform.position.x >= startPosition.x + patrolDistance)
            {
                movingRight = false;
            }
        }
        else
        {
            rb.linearVelocity = new Vector2(-moveSpeed, rb.linearVelocity.y);
            Flip(-1);
            if (transform.position.x <= startPosition.x - patrolDistance)
            {
                movingRight = true;
            }
        }
        if (animator != null)
        {
            animator.SetBool("IsAttacking", false);
        }
    }

    void Flip(float horizontalDirection)
    {
        if (horizontalDirection > 0 && transform.localScale.x < 0)
        {
            transform.localScale = new Vector3(Mathf.Abs(transform.localScale.x), transform.localScale.y, transform.localScale.z);
        }
        else if (horizontalDirection < 0 && transform.localScale.x > 0)
        {
            transform.localScale = new Vector3(-Mathf.Abs(transform.localScale.x), transform.localScale.y, transform.localScale.z);
        }
    }

    public void TakeDamage(int damage)
    {
        currentHealth -= damage;
        Debug.Log("Quái vật nhận " + damage + " sát thương. HP còn lại: " + currentHealth);

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    void Die()
    {
        Debug.Log("Quái vật đã chết!");
        Destroy(gameObject);
    }
}