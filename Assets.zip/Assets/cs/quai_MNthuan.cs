using UnityEngine;
using System.Collections;
using System.Collections.Generic;
public class Quai : MonoBehaviour
{
    public float speed = 5f;
    private int direction = 1;
    private Rigidbody2D rb;
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        if (rb == null)
        {
            Debug.LogError("Rigidbody2D not found on Quai GameObject. Please add one.");
            enabled = false;
        }
    }
    private void Update()
    {
        rb.linearVelocity = new Vector2(direction * speed, rb.linearVelocity.y);
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            direction *= -1;
            Flip();
        }
    }
    private void OnTriggerEnter2D(Collider2D other)
    {  
        if (other.CompareTag("Player"))
        {
            GameManager.Instance.GameOver();
        }
    }
    void Flip()
    {
        Vector3 currentScale = transform.localScale;
        currentScale.x *= -1;
        transform.localScale = currentScale;
    }
}