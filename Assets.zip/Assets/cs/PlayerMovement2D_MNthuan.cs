using UnityEngine;
using UnityEngine.UI;
public class PlayerMovement2D : MonoBehaviour
{
    public float moveSpeed = 5f;
    private float horizontalMovement;
    public float jumpForce = 10f;
    public Transform groundCheck;
    public LayerMask groundLayer;
    private bool isGrounded;
public GameObject transformedPlayerPrefab;
    private Rigidbody2D rb;
    private Animator animator;
    public int score = 0;
    public Text scoreText;
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        if (scoreText != null)
        {
            scoreText.text = "điểm " + score.ToString();
        }
    }
    void Update()
    {
        horizontalMovement = Input.GetAxisRaw("Horizontal");

        if (animator != null)
        {
            animator.SetFloat("Speed", Mathf.Abs(horizontalMovement));
        }
        if (horizontalMovement > 0)
        {
            transform.localScale = new Vector3(1, 1, 1);
        }
        else if (horizontalMovement < 0)
        {
       transform.localScale = new Vector3(-1, 1, 1);
        }

        isGrounded = Physics2D.OverlapCircle(groundCheck.position, 0.2f, groundLayer);

        if (animator != null)
        {
            animator.SetBool("IsGrounded", isGrounded);
            if (isGrounded)
            {
                animator.SetBool("IsJumping", false);
            }
        }
        if (Input.GetButtonDown("Jump") && isGrounded)
        {
            Jump();
            
        }
        if (animator != null)
        {
            if (!isGrounded && rb.linearVelocity.y < 0)
            {
                animator.SetBool("IsFalling", true);
                animator.SetBool("IsJumping", false);
            }
            else
            {
                animator.SetBool("IsFalling", false);
            }
        }
    }

    void FixedUpdate()
    {
        rb.linearVelocity = new Vector2(horizontalMovement * moveSpeed, rb.linearVelocity.y);
    }

    void Jump()
    {
        rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce);

        if (animator != null)
        {
            animator.SetBool("IsJumping", true);
            animator.SetBool("IsFalling", false);
        }
    }
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Apple_NMthuan"))
        {
            score += 4;
            if (scoreText != null)
            {
                scoreText.text = "điểm: " + score.ToString();
            }
            Destroy(other.gameObject);
        }
        else if (other.CompareTag("powerup"))
        {
            score += 10;
            TransformPlayer();
            Destroy(other.gameObject);
        }
    }
    public void LoseScore(int pointsLost)
    {
        score -= pointsLost;

        if (score < 0)
        {
            score = 0;
            Debug.Log("Điểm số đã về 0. Game Over hoặc xử lý khác.");
        }

        Debug.Log("Người chơi bị mất " + pointsLost + " điểm. Điểm còn lại: " + score);

        if (scoreText != null)
        {
            scoreText.text = "mau: " + score.ToString();
        }
    }
    void OnDrawGizmos()
    {
        if (groundCheck == null) return;
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(groundCheck.position, 0.2f);
    }
     void TransformPlayer()
    {
        if (transformedPlayerPrefab != null)
        {
            
            GameObject newPlayer = Instantiate(transformedPlayerPrefab, transform.position, transform.rotation);
            newPlayer.transform.localScale = transform.localScale;
            Debug.Log("Người chơi đã biến hình!");
            
            // Hủy Player hiện tại
            Destroy(gameObject); 
        }
        else
        {
            Debug.LogWarning("Chưa gán Transformed Player Prefab vào script PlayerMovement2D trên " + gameObject.name);
        }
    }
}