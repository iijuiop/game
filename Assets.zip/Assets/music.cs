using UnityEngine;
using UnityEngine.UI; // Thư viện cho UI (nút, thanh trượt...)

public class Music : MonoBehaviour // Khai báo lớp BackgroundMusic kế thừa từ MonoBehaviour
{
    private AudioSource audioSource; // Biến tham chiếu đến component AudioSource trên cùng GameObject

    void Start() // Hàm được gọi khi script được tải
    {
        audioSource = GetComponent<AudioSource>(); // Lấy component AudioSource từ GameObject này
        if (audioSource == null) // Kiểm tra nếu không tìm thấy AudioSource
        {
            Debug.LogError("AudioSource component not found on this GameObject for BackgroundMusic script.");
            return;
        }
        audioSource.loop = true; // Bật chế độ lặp lại cho âm thanh
        audioSource.Play(); // Bắt đầu phát nhạc
    }

    public void ToggleMusic() // Hàm công khai để bật/tắt nhạc
    {
        if (audioSource == null) return; // Đảm bảo audioSource không null

        if (audioSource.isPlaying) // Nếu nhạc đang phát
        {
            audioSource.Pause(); // Dừng nhạc tạm thời
        }
        else // Nếu nhạc không phát
        {
            audioSource.Play(); // Phát nhạc
        }
    }

    public void SetVolume(float volume) // Hàm công khai để thiết lập âm lượng
    {
        if (audioSource == null) return; // Đảm bảo audioSource không null
        audioSource.volume = volume; // Gán giá trị volume vào thuộc tính volume của AudioSource
    }
}