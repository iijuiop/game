using UnityEngine;
using UnityEngine.UI; // Cần thiết cho Text UI

public class bigcontroller : MonoBehaviour
{
    public float moveSpeed = 5f;
    private float horizontalMovement;
    public float jumpForce = 10f;
    public Transform groundCheck;
    public LayerMask groundLayer;
    private bool isGrounded;
    public GameObject transformedPlayerPrefab;
    private Rigidbody2D rb;
    private Animator animator;

    public int score = 0;
    public Text scoreText;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        if (scoreText != null)
        {
            scoreText.text = "điểm " + score.ToString();
        }
    }

    void Update()
    {
        horizontalMovement = Input.GetAxisRaw("Horizontal");

        if (animator != null)
        {
            animator.SetFloat("Speed", Mathf.Abs(horizontalMovement));
        }

        // Lật sprite theo hướng di chuyển
        if (horizontalMovement > 0)
        {
            transform.localScale = new Vector3(1, 1, 1);
        }
        else if (horizontalMovement < 0)
        {
            transform.localScale = new Vector3(-1, 1, 1);
        }

        isGrounded = Physics2D.OverlapCircle(groundCheck.position, 0.2f, groundLayer);

        if (animator != null)
        {
            animator.SetBool("IsGrounded", isGrounded);
            if (isGrounded)
            {
                animator.SetBool("IsJumping", false);
            }
        }

        if (Input.GetButtonDown("Jump") && isGrounded)
        {
            Jump();
        }

        if (animator != null)
        {
            if (!isGrounded && rb.linearVelocity.y < 0)
            {
                animator.SetBool("IsFalling", true);
                animator.SetBool("IsJumping", false);
            }
            else
            {
                animator.SetBool("IsFalling", false);
            }
        }
    }

    void FixedUpdate()
    {
        rb.linearVelocity = new Vector2(horizontalMovement * moveSpeed, rb.linearVelocity.y);
    }

    void Jump()
    {
        rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce);

        if (animator != null)
        {
            animator.SetBool("IsJumping", true);
            animator.SetBool("IsFalling", false);
        }
    }
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Enemy"))
        {
            TransformPlayer();
    }
    void TransformPlayer()
    {
        if (transformedPlayerPrefab != null)
        {
            GameObject newPlayer = Instantiate(transformedPlayerPrefab, transform.position, transform.rotation);
            newPlayer.transform.localScale = transform.localScale;
            Destroy(gameObject); 
        }

    }

    // Hàm OnDrawGizmos cần nằm bên trong class
    void OnDrawGizmos()
    {
        if (groundCheck == null) return;
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(groundCheck.position, 0.2f);
    }
}}